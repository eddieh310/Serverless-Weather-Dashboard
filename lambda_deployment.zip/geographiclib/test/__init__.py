"""

test_geodesic: test the geodesic routines from GeographicLib

Run these tests with one of

    python2 -m unittest -v geographiclib.test.test_geodesic
    python3 -m unittest -v geographiclib.test.test_geodesic

executed in this directory's parent directory.

"""
